from django.apps import AppConfig


class ClassifiedsConfig(AppConfig):
    name = 'classifieds'

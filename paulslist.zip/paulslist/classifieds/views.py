from django.shortcuts import render, get_object_or_404

from django.http import HttpResponse, HttpResponseRedirect
from django.urls import reverse

from .models import Post

# Create your views here.
def home(request):
    return render(request, "paulslist/dashboard.html")

def new_post(request):
    pass

def edit_post(request):
    pass

def search(request, search_word):
    if search_word is None:
        post_set = Post.objects.order_by('-pub_date')[:10]
    else:
        post_set = Post.objects.filter(description__contains = search_word)
    return render(request, 'classifieds/list-4.html', {'post_set': post_set})

def searching(request):
    try:
        post_set = Post.objects.filter(description__contains = request.GET['value'])
    except (KeyError, Choice.DoesNotExist):
        post_set = Post.objects.order_by('-pub_date')[:10]
    return render(request, 'classified/list-3.html', {'post_set': post_set})

from django.conf.urls import url

from . import views

app_name = 'classifieds'

urlpatterns = [
    url(r'^search/(?P<search_word>[a-z]+)$', views.search, name='search'),
    url(r'^search/inprocess/$', views.searching, name='searching'),
]
